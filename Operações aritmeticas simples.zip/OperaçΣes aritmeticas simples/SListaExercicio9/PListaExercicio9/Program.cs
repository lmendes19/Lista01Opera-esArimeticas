﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PListaExercicio9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor; 
            double resultado;
            Console.WriteLine("Exercício 9 da Lista 1"); 
            Console.WriteLine("");
            Console.Write("Digite o Valor do Diâmetro do Circulo: "); 
            valor = double.Parse(Console.ReadLine());
            resultado = Math.PI * Math.Pow((valor / 2), 2); 
            Console.WriteLine("Resultado: {0}", resultado);
            Console.ReadLine();

        }
    }
}
