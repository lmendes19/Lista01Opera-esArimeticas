﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PListaExercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1;
            double altura;
            double resultado;

            Console.WriteLine("Calcule a area de um triangulo a partir deste software");
            Console.WriteLine("Entre com o valor da base");
            base1 = int.Parse("Console.ReadLine");
            Console.WriteLine("Entre com o valor da altura");
            altura = int.Parse("Console.ReadLine");
            resultado = base1 * altura / 2;
            Console.WriteLine("Aqui esta o valor da area do triangulo");
            Console.WriteLine(resultado);
            Console.ReadLine();

        }
    }
}
