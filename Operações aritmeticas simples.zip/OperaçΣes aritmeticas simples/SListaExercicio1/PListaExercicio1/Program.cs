﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PListaExercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1;
            double altura2;
            double resultado;

            Console.WriteLine("Calcule a area de um retangulo atraves desse software");
            Console.WriteLine("Entre com o valor da base de um retangulo");
            base1 =  int.Parse(Console.ReadLine());
            Console.WriteLine("Entre com o valor da altura de um retangulo");
            altura2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Aqui está o valor da area do retangulo");
            resultado = base1 * altura2;
            
            Console.WriteLine(resultado);
            Console.ReadLine(); 

        }
    }
}
